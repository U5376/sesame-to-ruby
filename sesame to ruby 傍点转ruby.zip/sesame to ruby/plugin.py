import sys
from sigil_bs4 import BeautifulSoup
from PyQt5.QtWidgets import QApplication, QInputDialog

def run(bk):
    app = QApplication([])
    class_name, ok = QInputDialog.getText(None, 'Class确认', '输入傍点class名称 (默认 em-sesame): ', text='em-sesame')
    class_name = class_name if ok else 'em-sesame'

    for (file_id, href) in bk.text_iter():
        html = bk.readfile(file_id)
        modified_html = modify_html(html, class_name)
        bk.writefile(file_id, modified_html)
    return 0

def modify_html(html, class_name):
    soup = BeautifulSoup(html)
    for span in soup.find_all('span', class_=class_name):
        ruby = soup.new_tag('ruby')
        for char in span.string:
            ruby.append(soup.new_string(char))
            rt_tag = soup.new_tag('rt')
            rt_tag.append(soup.new_string("・"))
            ruby.append(rt_tag)
        span.replace_with(ruby)
    return str(soup)

def main():
    print("I reached main when I should not have\n")
    return -1

if __name__ == "__main__":
    sys.exit(main())
